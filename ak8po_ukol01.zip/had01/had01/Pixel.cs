
using System;
// using System.Collections.Generic;
using System.Linq;
// using System.Text;
// using System.Threading.Tasks; // ve VS jede, zde zašpérováno
// using System.Threading;

namespace had01
{
	
	// START class pixel ----------  
        class Pixel
        {
            public int xpos { get; set; }
            public int ypos { get; set; }
            public ConsoleColor schermkleur { get; set; }
        }
// END ----------
	
	
}



