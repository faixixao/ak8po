using System;
// using System.Collections.Generic;
using System.Linq;
// using System.Text;
// using System.Threading.Tasks; // ve VS jede, zde zašpérováno
// using System.Threading;

namespace had01
{

	
	public class Border
	{
		
      
// START vykreslení hranic DrawBorder() ----------        
        // private static void DrawBorder(int screenwidth, int screenheight)
        public Border(int screenwidth, int screenheight)
        {
            var horizontalBar = string.Join("", new byte[screenwidth].Select(b => "■").ToArray());
            
            Console.SetCursorPosition(0, 0);
            Console.Write(horizontalBar);
            Console.SetCursorPosition(0, screenheight - 1);
            Console.Write(horizontalBar);
           
            for (int i = 0; i < screenheight; i++)
            {
                Console.SetCursorPosition(0, i);
                Console.Write("■");
                Console.SetCursorPosition(screenwidth - 1, i);
                Console.Write("■");
            }
            
        }
// END ----------
       
       
	}
}
